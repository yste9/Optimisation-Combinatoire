Phase 3 - Mode d'emploi

1) Résoudre une instance :
python phase3_autonomous_solver.py solve "Vehicules-Autonomes 01.docx" -o "Vehicules-Autonomes 01.out"

2) Lancer le benchmark des deux instances :
python run_phase3_benchmark.py

3) Fichiers produits :
- phase3_outputs/benchmark_results.csv
- phase3_outputs/Rapport_Phase3_Benchmark.md
- phase3_outputs/Vehicules-Autonomes 01.out
- phase3_outputs/Vehicules-Autonomes 02.out
