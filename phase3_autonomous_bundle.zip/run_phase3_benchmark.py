
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import subprocess
import sys

BASE = os.path.dirname(os.path.abspath(__file__))

INSTANCE_1 = os.path.join(BASE, "Vehicules-Autonomes 01.docx")
INSTANCE_2 = os.path.join(BASE, "Vehicules-Autonomes 02.docx")
OUTPUT_DIR = os.path.join(BASE, "phase3_outputs")

cmd = [
    sys.executable,
    os.path.join(BASE, "phase3_autonomous_solver.py"),
    "benchmark",
    INSTANCE_1,
    INSTANCE_2,
    "--output-dir",
    OUTPUT_DIR,
    "--csv",
    "benchmark_results.csv",
    "--md",
    "Rapport_Phase3_Benchmark.md",
    "--seed",
    "0",
    "--starts",
    "3",
]

raise SystemExit(subprocess.call(cmd))
