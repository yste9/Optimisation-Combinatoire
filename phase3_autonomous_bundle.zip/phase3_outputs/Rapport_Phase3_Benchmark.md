# Rapport Phase 3 — Implémentation et tests

## 1. Contenu

Le code implémente une heuristique constructive gloutonne pondérée, puis une métaheuristique de type LNS (destroy / repair).

## 2. Protocole de test

- Construction d'une solution initiale par multi-start glouton.
- Amélioration de cette solution par LNS.
- Export de la solution au format attendu : une ligne par véhicule.

## 3. Résultats

| Instance | F | N | Score initial | Score final | Rides initiaux | Rides finaux | Temps (s) |
|---|---:|---:|---:|---:|---:|---:|---:|
| Vehicules-Autonomes 01.docx | 100 | 300 | 176852 | 176852 | 294 | 294 | 2.13 |
| Vehicules-Autonomes 02.docx | 400 | 10000 | 4692863 | 5946305 | 845 | 1704 | 5.056 |

## 4. Analyse

L'heuristique constructive permet d'obtenir rapidement une solution réalisable. La phase LNS améliore ensuite le score en retirant une partie des rides, puis en les réinsérant différemment.

Cette approche est cohérente avec les phases précédentes du projet : la représentation en séquences de rides par véhicule est conservée, et le score intègre à la fois la distance des rides et le bonus de départ à l'heure.

## 5. Fichiers produits

- `Vehicules-Autonomes 01.out` : solution pour Vehicules-Autonomes 01.docx
- `Vehicules-Autonomes 02.out` : solution pour Vehicules-Autonomes 02.docx
