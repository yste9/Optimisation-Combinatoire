
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Phase 3 - Projet M1 OC 2026
Implémentation d'une heuristique constructive et d'une métaheuristique de type LNS
pour le problème des véhicules autonomes / rides pré-réservés.

Fonctionnalités :
- lecture d'instances au format texte ou .docx ;
- construction d'une solution initiale par heuristique gloutonne pondérée ;
- amélioration de la solution par LNS (destroy / repair) ;
- export des solutions au format demandé ;
- benchmark et génération d'un rapport Markdown / CSV.

Utilisation :
    python phase3_autonomous_solver.py solve "Vehicules-Autonomes 01.docx" -o inst1.out
    python phase3_autonomous_solver.py benchmark "Vehicules-Autonomes 01.docx" "Vehicules-Autonomes 02.docx"
"""

from __future__ import annotations

import argparse
import csv
import html
import math
import os
import random
import re
import sys
import time
import zipfile
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence, Tuple


# =========================
# Structures de données
# =========================

@dataclass(frozen=True)
class Ride:
    rid: int
    a: int
    b: int
    x: int
    y: int
    s: int
    f: int
    d: int
    latest_start: int


@dataclass
class VehicleState:
    vid: int
    pos: Tuple[int, int] = (0, 0)
    t: int = 0


class RidePool:
    """Pool dynamique de rides libres avec suppression O(1)."""

    def __init__(self, ride_ids: Iterable[int]) -> None:
        self.ids: List[int] = list(ride_ids)
        self.pos: Dict[int, int] = {rid: i for i, rid in enumerate(self.ids)}

    def __len__(self) -> int:
        return len(self.ids)

    def remove(self, rid: int) -> None:
        i = self.pos.pop(rid)
        last = self.ids[-1]
        if i != len(self.ids) - 1:
            self.ids[i] = last
            self.pos[last] = i
        self.ids.pop()

    def add(self, rid: int) -> None:
        if rid in self.pos:
            return
        self.pos[rid] = len(self.ids)
        self.ids.append(rid)

    def sample(self, k: int, rng: random.Random) -> List[int]:
        n = len(self.ids)
        if n == 0:
            return []
        if k >= n:
            return list(self.ids)
        return rng.sample(self.ids, k)


# =========================
# Lecture d'instance
# =========================

def manhattan(p: Tuple[int, int], q: Tuple[int, int]) -> int:
    return abs(p[0] - q[0]) + abs(p[1] - q[1])


def extract_text_from_docx(path: str) -> str:
    with zipfile.ZipFile(path) as zf:
        data = zf.read("word/document.xml").decode("utf-8")
    data = re.sub(r"</w:p>", "\n", data)
    data = re.sub(r"<[^>]+>", "", data)
    return html.unescape(data)


def read_instance(path: str) -> Dict[str, object]:
    if path.lower().endswith(".docx"):
        text = extract_text_from_docx(path)
    else:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()

    nums = list(map(int, re.findall(r"-?\d+", text)))
    if len(nums) < 6:
        raise ValueError(f"Fichier d'instance illisible : {path}")

    R, C, F, N, B, T = nums[:6]
    arr = nums[6:]
    if len(arr) < 6 * N:
        raise ValueError(
            f"Instance incomplète : {len(arr)//6} rides lues pour N={N} dans {path}"
        )

    rides: List[Ride] = []
    for i in range(N):
        a, b, x, y, s, f = arr[6 * i : 6 * i + 6]
        d = abs(a - x) + abs(b - y)
        rides.append(Ride(i, a, b, x, y, s, f, d, f - d))

    return {
        "name": os.path.basename(path),
        "path": path,
        "R": R,
        "C": C,
        "F": F,
        "N": N,
        "B": B,
        "T": T,
        "rides": rides,
    }


# =========================
# Évaluation d'une solution
# =========================

def ride_eval_from_state(
    state: VehicleState, ride: Ride, bonus_value: int, horizon: int
) -> Optional[Tuple[int, int, int, int, int, int]]:
    """
    Retourne (deadhead, arrive, start, finish, wait, bonus)
    si le ride est faisable depuis l'état courant du véhicule.
    """
    deadhead = abs(state.pos[0] - ride.a) + abs(state.pos[1] - ride.b)
    arrive = state.t + deadhead
    if arrive > ride.latest_start:
        return None

    start = max(arrive, ride.s)
    finish = start + ride.d
    if finish > ride.f or finish > horizon:
        return None

    wait = max(0, ride.s - arrive)
    bonus = bonus_value if start == ride.s else 0
    return deadhead, arrive, start, finish, wait, bonus


def compute_score(
    routes: Sequence[Sequence[int]], rides: Sequence[Ride], bonus_value: int, horizon: int
) -> int:
    score = 0
    seen = set()

    for route in routes:
        pos = (0, 0)
        t = 0
        for rid in route:
            if rid in seen:
                continue

            ride = rides[rid]
            deadhead = abs(pos[0] - ride.a) + abs(pos[1] - ride.b)
            arrive = t + deadhead
            start = max(arrive, ride.s)
            finish = start + ride.d

            if arrive <= ride.latest_start and finish <= ride.f and finish <= horizon:
                score += ride.d + (bonus_value if start == ride.s else 0)
                seen.add(rid)
                pos = (ride.x, ride.y)
                t = finish
            else:
                break

    return score


def count_served_rides(
    routes: Sequence[Sequence[int]], rides: Sequence[Ride], horizon: int
) -> int:
    served = 0
    seen = set()

    for route in routes:
        pos = (0, 0)
        t = 0
        for rid in route:
            if rid in seen:
                continue
            ride = rides[rid]
            deadhead = abs(pos[0] - ride.a) + abs(pos[1] - ride.b)
            arrive = t + deadhead
            start = max(arrive, ride.s)
            finish = start + ride.d
            if arrive <= ride.latest_start and finish <= ride.f and finish <= horizon:
                served += 1
                seen.add(rid)
                pos = (ride.x, ride.y)
                t = finish
            else:
                break
    return served


# =========================
# Heuristique constructive
# =========================

def greedy_construct(
    instance: Dict[str, object],
    seed: int = 0,
    sample_size: int = 500,
    alpha: float = 0.30,
    beta: float = 0.15,
    time_budget: float = 2.0,
) -> List[List[int]]:
    """
    Heuristique gloutonne pondérée :
    on choisit à chaque étape le couple (véhicule, ride) offrant
    un bon compromis entre score du ride, distance d'accès et attente.
    """
    rides: List[Ride] = instance["rides"]  # type: ignore[assignment]
    F: int = int(instance["F"])
    B: int = int(instance["B"])
    T: int = int(instance["T"])

    rng = random.Random(seed)
    candidate_ids = [
        r.rid
        for r in rides
        if r.latest_start >= 0 and manhattan((0, 0), (r.a, r.b)) <= T
    ]
    pool = RidePool(candidate_ids)

    vehicles = [VehicleState(v) for v in range(F)]
    routes: List[List[int]] = [[] for _ in range(F)]
    order = list(range(F))
    t0 = time.perf_counter()

    while len(pool) > 0 and (time.perf_counter() - t0) < time_budget:
        progress = False
        rng.shuffle(order)

        for vid in order:
            if len(pool) == 0 or (time.perf_counter() - t0) >= time_budget:
                break

            veh = vehicles[vid]
            sampled = pool.sample(min(sample_size, len(pool)), rng)

            best_rid: Optional[int] = None
            best_finish = 0
            best_pos = (0, 0)
            best_val = -10**18

            for rid in sampled:
                ride = rides[rid]
                ev = ride_eval_from_state(veh, ride, B, T)
                if ev is None:
                    continue

                deadhead, arrive, start, finish, wait, bonus = ev

                # Critère pondéré de la phase 2
                value = ride.d + bonus - alpha * deadhead - beta * wait

                # Petit biais pour finir tôt et laisser de la place à la suite
                value -= 0.0005 * finish

                # Léger encouragement pour les rides à faible marge
                slack = max(ride.latest_start - arrive, 0)
                value += 4.0 / (1.0 + slack)

                if value > best_val:
                    best_val = value
                    best_rid = rid
                    best_finish = finish
                    best_pos = (ride.x, ride.y)

            if best_rid is not None:
                routes[vid].append(best_rid)
                veh.t = best_finish
                veh.pos = best_pos
                pool.remove(best_rid)
                progress = True

        if not progress:
            break

    return routes


# =========================
# Outils de nettoyage / réparation
# =========================

def clean_routes(
    routes: Sequence[Sequence[int]], rides: Sequence[Ride], horizon: int
) -> Tuple[List[List[int]], List[int], List[VehicleState], set]:
    cleaned: List[List[int]] = []
    removed: List[int] = []
    states: List[VehicleState] = []
    seen = set()

    for vid, route in enumerate(routes):
        pos = (0, 0)
        t = 0
        valid: List[int] = []

        for rid in route:
            if rid in seen:
                removed.append(rid)
                continue

            ride = rides[rid]
            deadhead = abs(pos[0] - ride.a) + abs(pos[1] - ride.b)
            arrive = t + deadhead
            start = max(arrive, ride.s)
            finish = start + ride.d

            if arrive <= ride.latest_start and finish <= ride.f and finish <= horizon:
                valid.append(rid)
                seen.add(rid)
                pos = (ride.x, ride.y)
                t = finish
            else:
                removed.append(rid)

        cleaned.append(valid)
        states.append(VehicleState(vid, pos, t))

    return cleaned, removed, states, seen


def repair_append(
    routes: List[List[int]],
    states: List[VehicleState],
    pool: RidePool,
    rides: Sequence[Ride],
    bonus_value: int,
    horizon: int,
    rng: random.Random,
    sample_size: int = 500,
    alpha: float = 0.25,
    beta: float = 0.15,
    time_budget: float = 0.8,
) -> None:
    """
    Réparation simple : on réinsère les rides libres en fin de séquence.
    """
    t0 = time.perf_counter()
    order = list(range(len(states)))

    while len(pool) > 0 and (time.perf_counter() - t0) < time_budget:
        progress = False
        rng.shuffle(order)

        for vid in order:
            if len(pool) == 0 or (time.perf_counter() - t0) >= time_budget:
                break

            state = states[vid]
            sampled = pool.sample(min(sample_size, len(pool)), rng)

            best_rid: Optional[int] = None
            best_finish = 0
            best_pos = (0, 0)
            best_val = -10**18

            for rid in sampled:
                ride = rides[rid]
                ev = ride_eval_from_state(state, ride, bonus_value, horizon)
                if ev is None:
                    continue

                deadhead, arrive, start, finish, wait, bonus = ev
                value = ride.d + bonus - alpha * deadhead - beta * wait - 0.0005 * finish

                if value > best_val:
                    best_val = value
                    best_rid = rid
                    best_finish = finish
                    best_pos = (ride.x, ride.y)

            if best_rid is not None:
                routes[vid].append(best_rid)
                state.t = best_finish
                state.pos = best_pos
                pool.remove(best_rid)
                progress = True

        if not progress:
            break


# =========================
# Métaheuristique LNS
# =========================

def lns_improve(
    instance: Dict[str, object],
    base_routes: Sequence[Sequence[int]],
    seed: int = 0,
    time_budget: float = 5.0,
    remove_frac: float = 0.12,
    sample_size: int = 400,
) -> Tuple[List[List[int]], int]:
    """
    LNS simple :
    - destruction partielle (random ou worst removal),
    - réparation par réinsertion gloutonne,
    - acceptation inspirée du recuit simulé.
    """
    rides: List[Ride] = instance["rides"]  # type: ignore[assignment]
    B: int = int(instance["B"])
    T: int = int(instance["T"])

    rng = random.Random(seed)

    best_routes = [list(route) for route in base_routes]
    best_score = compute_score(best_routes, rides, B, T)

    current_routes = [list(route) for route in best_routes]
    current_score = best_score

    t0 = time.perf_counter()

    while (time.perf_counter() - t0) < time_budget:
        assigned = [rid for route in current_routes for rid in route]
        if not assigned:
            break

        k = max(1, int(remove_frac * len(assigned)))

        if rng.random() < 0.5:
            remove_set = set(rng.sample(assigned, min(k, len(assigned))))
        else:
            scored = sorted(assigned, key=lambda rid: rides[rid].d)
            take_worst = scored[: min(k // 2, len(scored))]
            take_random = rng.sample(
                assigned, min(k - len(take_worst), len(assigned))
            )
            remove_set = set(take_worst + take_random)

        candidate = [
            [rid for rid in route if rid not in remove_set] for route in current_routes
        ]
        candidate, _, states, present = clean_routes(candidate, rides, T)

        free_ids = [r.rid for r in rides if r.rid not in present]
        pool = RidePool(free_ids)

        repair_append(
            candidate,
            states,
            pool,
            rides,
            B,
            T,
            rng,
            sample_size=sample_size,
            time_budget=min(0.8, time_budget / 8),
        )

        candidate_score = compute_score(candidate, rides, B, T)

        elapsed = time.perf_counter() - t0
        temperature = max(1.0, 500.0 * (1.0 - elapsed / time_budget))

        accept = candidate_score >= current_score
        if not accept:
            delta = candidate_score - current_score
            try:
                accept = rng.random() < math.exp(delta / temperature)
            except OverflowError:
                accept = False

        if accept:
            current_routes = candidate
            current_score = candidate_score

            if candidate_score > best_score:
                best_score = candidate_score
                best_routes = [list(route) for route in candidate]

    return best_routes, best_score


# =========================
# Résolution complète
# =========================

def solve_instance(
    instance: Dict[str, object],
    seed: int = 0,
    initial_seconds: float = 2.5,
    lns_seconds: float = 5.0,
    starts: int = 4,
) -> Tuple[List[List[int]], Dict[str, float]]:
    rides: List[Ride] = instance["rides"]  # type: ignore[assignment]
    B: int = int(instance["B"])
    T: int = int(instance["T"])

    best_init_routes: List[List[int]] = [[] for _ in range(int(instance["F"]))]
    best_init_score = -1

    t0 = time.perf_counter()
    init_start = time.perf_counter()
    for k in range(starts):
        remaining = initial_seconds - (time.perf_counter() - init_start)
        if remaining <= 0:
            break

        routes = greedy_construct(
            instance,
            seed=seed + 97 * k,
            time_budget=max(0.2, remaining / max(1, starts - k)),
        )
        score = compute_score(routes, rides, B, T)
        if score > best_init_score:
            best_init_score = score
            best_init_routes = routes

    routes, final_score = lns_improve(
        instance,
        best_init_routes,
        seed=seed + 999,
        time_budget=lns_seconds,
    )
    total_time = time.perf_counter() - t0

    stats = {
        "initial_score": float(best_init_score),
        "final_score": float(final_score),
        "served_initial": float(count_served_rides(best_init_routes, rides, T)),
        "served_final": float(count_served_rides(routes, rides, T)),
        "elapsed_seconds": total_time,
    }
    return routes, stats


# =========================
# Export / benchmark
# =========================

def save_solution(path: str, routes: Sequence[Sequence[int]]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for route in routes:
            if route:
                f.write(f"{len(route)} {' '.join(map(str, route))}\n")
            else:
                f.write("0\n")


def benchmark_instances(
    instance_paths: Sequence[str],
    output_dir: str,
    seed: int = 0,
    init_small: float = 1.5,
    lns_small: float = 2.0,
    init_large: float = 2.0,
    lns_large: float = 3.0,
    starts: int = 3,
) -> List[Dict[str, object]]:
    os.makedirs(output_dir, exist_ok=True)
    results: List[Dict[str, object]] = []

    for idx, path in enumerate(instance_paths):
        instance = read_instance(path)
        N = int(instance["N"])
        if N <= 1000:
            initial_seconds = init_small
            lns_seconds = lns_small
        else:
            initial_seconds = init_large
            lns_seconds = lns_large

        routes, stats = solve_instance(
            instance,
            seed=seed + idx * 1000,
            initial_seconds=initial_seconds,
            lns_seconds=lns_seconds,
            starts=starts,
        )

        base_name = os.path.splitext(os.path.basename(path))[0]
        out_path = os.path.join(output_dir, f"{base_name}.out")
        save_solution(out_path, routes)

        row = {
            "instance": instance["name"],
            "R": instance["R"],
            "C": instance["C"],
            "F": instance["F"],
            "N": instance["N"],
            "B": instance["B"],
            "T": instance["T"],
            "score_initial": int(stats["initial_score"]),
            "score_final": int(stats["final_score"]),
            "rides_initial": int(stats["served_initial"]),
            "rides_final": int(stats["served_final"]),
            "elapsed_seconds": round(float(stats["elapsed_seconds"]), 3),
            "solution_file": out_path,
        }
        results.append(row)

    return results


def write_csv(path: str, rows: Sequence[Dict[str, object]]) -> None:
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter=";")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def write_markdown_report(path: str, rows: Sequence[Dict[str, object]]) -> None:
    lines: List[str] = []
    lines.append("# Rapport Phase 3 — Implémentation et tests")
    lines.append("")
    lines.append("## 1. Contenu")
    lines.append("")
    lines.append(
        "Le code implémente une heuristique constructive gloutonne pondérée, "
        "puis une métaheuristique de type LNS (destroy / repair)."
    )
    lines.append("")
    lines.append("## 2. Protocole de test")
    lines.append("")
    lines.append("- Construction d'une solution initiale par multi-start glouton.")
    lines.append("- Amélioration de cette solution par LNS.")
    lines.append("- Export de la solution au format attendu : une ligne par véhicule.")
    lines.append("")
    lines.append("## 3. Résultats")
    lines.append("")
    lines.append("| Instance | F | N | Score initial | Score final | Rides initiaux | Rides finaux | Temps (s) |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|")
    for row in rows:
        lines.append(
            f"| {row['instance']} | {row['F']} | {row['N']} | "
            f"{row['score_initial']} | {row['score_final']} | "
            f"{row['rides_initial']} | {row['rides_final']} | {row['elapsed_seconds']} |"
        )
    lines.append("")
    lines.append("## 4. Analyse")
    lines.append("")
    lines.append(
        "L'heuristique constructive permet d'obtenir rapidement une solution réalisable. "
        "La phase LNS améliore ensuite le score en retirant une partie des rides, "
        "puis en les réinsérant différemment."
    )
    lines.append("")
    lines.append(
        "Cette approche est cohérente avec les phases précédentes du projet : "
        "la représentation en séquences de rides par véhicule est conservée, "
        "et le score intègre à la fois la distance des rides et le bonus de départ à l'heure."
    )
    lines.append("")
    lines.append("## 5. Fichiers produits")
    lines.append("")
    for row in rows:
        lines.append(f"- `{os.path.basename(str(row['solution_file']))}` : solution pour {row['instance']}")
    lines.append("")

    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


# =========================
# Interface en ligne de commande
# =========================

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Phase 3 - Heuristique + LNS pour véhicules autonomes"
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    solve_p = sub.add_parser("solve", help="Résoudre une instance")
    solve_p.add_argument("instance", help="Chemin de l'instance (.docx ou .txt)")
    solve_p.add_argument("-o", "--output", default="solution.out", help="Fichier de sortie")
    solve_p.add_argument("--seed", type=int, default=0)
    solve_p.add_argument("--initial", type=float, default=2.5, help="Temps heuristique initiale")
    solve_p.add_argument("--lns", type=float, default=5.0, help="Temps LNS")
    solve_p.add_argument("--starts", type=int, default=4, help="Nombre de multi-starts")

    bench_p = sub.add_parser("benchmark", help="Lancer les tests phase 3")
    bench_p.add_argument("instances", nargs="+", help="Liste des instances à tester")
    bench_p.add_argument("--output-dir", default="phase3_outputs")
    bench_p.add_argument("--csv", default="benchmark_results.csv")
    bench_p.add_argument("--md", default="Rapport_Phase3_Benchmark.md")
    bench_p.add_argument("--seed", type=int, default=0)
    bench_p.add_argument("--starts", type=int, default=3)

    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.cmd == "solve":
        instance = read_instance(args.instance)
        routes, stats = solve_instance(
            instance,
            seed=args.seed,
            initial_seconds=args.initial,
            lns_seconds=args.lns,
            starts=args.starts,
        )
        save_solution(args.output, routes)

        print(f"Instance : {instance['name']}")
        print(f"Score initial : {int(stats['initial_score'])}")
        print(f"Score final   : {int(stats['final_score'])}")
        print(f"Rides servis  : {int(stats['served_final'])}")
        print(f"Temps total   : {stats['elapsed_seconds']:.3f} s")
        print(f"Sortie        : {args.output}")
        return 0

    if args.cmd == "benchmark":
        results = benchmark_instances(
            args.instances,
            output_dir=args.output_dir,
            seed=args.seed,
            starts=args.starts,
        )
        csv_path = os.path.join(args.output_dir, args.csv)
        md_path = os.path.join(args.output_dir, args.md)
        write_csv(csv_path, results)
        write_markdown_report(md_path, results)

        print("Benchmark terminé.")
        print(f"CSV     : {csv_path}")
        print(f"Rapport : {md_path}")
        for row in results:
            print(
                f"- {row['instance']}: score initial={row['score_initial']}, "
                f"score final={row['score_final']}, temps={row['elapsed_seconds']} s"
            )
        return 0

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
